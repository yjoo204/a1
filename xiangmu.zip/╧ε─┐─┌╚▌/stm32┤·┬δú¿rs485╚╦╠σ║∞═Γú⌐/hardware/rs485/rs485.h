#ifndef _rs485_H
#define _rs485_H

#include "sys.h"
#include "stdio.h"
#include "string.h"

#define BUF4LEN 256      //���黺���С
typedef struct _UART4_BUF
{
    char buf [BUF4LEN+1];               
    unsigned int index ;
		char rx_flag;
}UART4_BUF;	


//ģʽ����
#define RS485_TX_EN		PDout(3)	//485ģʽ����.0,����;1,����.
														 
void RS485_Init(u32 bound);
void Clear_usrt4buf(void);
void RS485_SendStr(char*SendBuf);
void UART4_IRQHandler(void);
u8 GetTemperatureAndHumidity(u8 *temperature, u8 *humidity);


extern UART4_BUF Uart4_buff;

#endif
