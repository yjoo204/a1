#ifndef _DELAY_H_
#define _DELAY_H_







void Delay_Init(void);

void delay_us(unsigned short us);

void delay_ms(unsigned short ms);

#endif
