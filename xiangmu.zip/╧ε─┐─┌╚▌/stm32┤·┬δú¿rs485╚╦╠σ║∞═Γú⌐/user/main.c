//单片机头文件
#include "stm32f10x.h"

//网络协议层
#include "onenet.h"

//网络设备
#include "esp8266.h"

//硬件驱动
#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "dht11.h"
#include "led.h"
#include "key.h"
#include "adc.h"
#include "gm.h"
#include "rs485.h"
//C库
#include <string.h>


#define ESP8266_ONENET_INFO		"AT+CIPSTART=\"TCP\",\"mqtts.heclouds.com\",1883\r\n"

extern unsigned int Usart1_RxCounter;      //定义一个变量，记录串口1总共接收了多少字节的数据
extern char Usart1_RxBuff[USART1_RXBUFF_SIZE]; //定义一个数组，用于保存串口1接收到的数据 

void USART3_IRQHandler(void);
char rs485_rec[100];
char Send_buffer[] = {0x01,0x03,0x00,0x03,0x00,0x01,0x74,0x0a};


u8 temperature=0,humidity=0,gadc=0;


//float temp = 0;
//float humi = 0;
u8 temp = 20;
u8 humi = 35;
u8 buf_string[20];

u8 heart = 0;
u8 G = 0;
u8 car_state = 0;

u8 temph = 40;
u8 humih = 70;
u8 hearth = 40;
u8 Gh = 40;

u8 bufang = 0;

u32 alarm_cnt = 0;
uint8_t person_detected = 0; // 0: 无人，1: 有人
int zigbee_temp=0, zigbee_hum=0, zigbee_light=0;  // 存储最终数据的变量
/*
************************************************************
*	函数名称：	Hardware_Init
*
*	函数功能：	硬件初始化
*
*	入口参数：	无
*
*	返回参数：	无
*
*	说明：		初始化单片机功能以及外接设备
************************************************************
*/
void Hardware_Init(void)
{
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);	//中断控制器分组设置
	Delay_Init();									//systick初始化
	Usart1_Init(9600);							//串口1，打印信息用
	Usart2_Init(115200);							//串口2，驱动ESP8266用
	RS485_Init(9600);//串口4，rs485初始化
	Usart3_Init(9600);
	RS485_TX_EN=0;
	LED_Init();
	KEY_Init();
	Adc_Init();
	UsartPrintf(USART_DEBUG, " Hardware init OK\r\n");
	
}

/*
************************************************************
*	函数名称：	main
*
*	函数功能：	
*
*	入口参数：	无
*
*	返回参数：	0
*
*	说明：		
************************************************************
*/

float ConvertToRealValue(u8 highByte, u8 lowByte, u16 multiplier) {
    // 合并两个字节为一个16位无符号整数
    u16 rawValue = (highByte << 8) | lowByte;
    
    float realValue;
    
    // 判断是否为负数（补码形式）
    if (rawValue > 32768) {
        // 负数处理：(原始值 - 65535) / 倍率
        realValue = (float)(rawValue - 65535) / multiplier;
    } else {
        // 正数处理：原始值 / 倍率
        realValue = (float)rawValue / multiplier;
    }
    
    return realValue;
}


int main(void)
{

	
	
	u8 set_flag = 0;
	u8 set_type = 0;
	 
	u8 key_val = 0;

	
	unsigned short timeCount = 0;	//发送间隔变量
	
	unsigned char *dataPtr = NULL;

	Hardware_Init();				//初始化外围硬件
	
	
	#if 1
	
	ESP8266_Init();					//初始化ESP8266
	UsartPrintf(USART_DEBUG, "Connect MQTTs Server...\r\n");
	
	
	
	while(ESP8266_SendCmd(ESP8266_ONENET_INFO, "CONNECT"))
		delay_ms(500);
	UsartPrintf(USART_DEBUG, "NET_OK\r\n");
	
	while(OneNet_DevLink())			//接入OneNET
	FS = 1;
	KT = 1;
	delay_ms(500);
	FS = 0;
	KT = 0;
	OneNET_Subscribe();
	#endif

	while(1)
	{
		
	  int i=0;
		delay_ms(3000);
		RS485_SendStr(Send_buffer);
		delay_ms(200);  // 等待200ms，根据实际情况调整
		if(Uart4_buff.rx_flag == 1)
{
    // 声明所有变量在可执行语句之前
    u8 i;
    u8 highByteTemp, lowByteTemp, highByteHumi, lowByteHumi;
    u16 combinedTempValue, combinedHumiValue;
    float temperature, humidity;
    
    // 打印原始数据
    for(i=0; i<11; i++)
    {
			UsartPrintf(USART_DEBUG, "%02x ", Uart4_buff.buf[i]);
    }
    
    // 确保数据长度足够
		
if (Uart4_buff.index >= 7) // 确保数据长度足够
{
		
    // 提取第4和第5个字节 (索引3和4) 作为状态位
    uint8_t statusHighByte = Uart4_buff.buf[3];
    uint8_t statusLowByte = Uart4_buff.buf[4];
    
    // 合并为16位值
    uint16_t statusValue = (statusHighByte << 8) | statusLowByte;
    
    // 判断状态
    if (statusValue == 1) {
        // 状态为1，表示检测到有人
        person_detected = 1;
        UsartPrintf(USART_DEBUG, "youren\r\n");//拼音有人
    } else if (statusValue == 0) {
        // 状态为0，表示无人
        person_detected = 0;
        UsartPrintf(USART_DEBUG, "wuren\r\n");//拼音无人
    } else {
        // 异常状态
        UsartPrintf(USART_DEBUG, "yichang (%d)\n", statusValue);//异常
    }
}
// 清除接收标志，准备接收下一帧数据
Clear_usrt4buf();
}
delay_ms(10);
if(buf_uart3.flag == 1)
{
    // 1. 所有变量声明移到代码块最开始（符合C89标准）
    int num1 = 0, num2 = 0, num3 = 0;       // 用于存储解析的数字
    char *ptr;                             // 指针变量（先声明，后赋值）
   

    // 2. 原有执行语句
    delay_ms(50);
    UsartPrintf(USART_DEBUG,"Received UART3 Data(zigbee): ");
    UsartPrintf(USART_DEBUG,"%s\r\n",buf_uart3.buf);
    UsartPrintf(USART_DEBUG,"\r\n");

    // 3. 字符串解析逻辑
    // 解决"u8*"转"char*"的类型警告（强制类型转换）
    ptr = (char*)buf_uart3.buf;

    // 查找目标字符串"Received UART3 Dat"（兼容串口打印的截断情况，如"ived UART3 Dat"）
    // 注：如果串口数据有截断，可缩短匹配字符串，例如用"UART3 Dat"
    ptr = strstr(ptr, "UART3 Dat");
    if(ptr != NULL) 
    {
        // 跳过"UART3 Dat"，指向数字部分（如"52,25 146"）
        ptr += strlen("UART3 Dat");
        // 解析格式：数字1,数字2 数字3（如52,25 146）
        if(sscanf(ptr, "%d,%d %d", &num1, &num2, &num3) == 3) 
        {
            // 成功解析后赋值给变量
            zigbee_temp = num1;    // 52
            zigbee_hum = num2;     // 25
            zigbee_light = num3;   // 146
        }
    }
	
    // 4. 清除缓冲区
    buf_uart3.flag = 0;
    memset(buf_uart3.buf, 0, BUFLEN);
}
			
			OneNet_SendData();									//发送数据
			timeCount = 0;
			ESP8266_Clear();
			
			LED0 = !LED0;
		
		dataPtr = ESP8266_GetIPD(0);
		if(dataPtr != NULL)
			OneNet_RevPro(dataPtr);
		
		delay_ms(1);
		
	}
	}




