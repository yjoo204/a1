package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.io.UnsupportedEncodingException;
import javax.net.ssl.HttpsURLConnection;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "OneNetDemo";
    // OneNet平台配置（需替换为你的设备信息）
    private String deviceName = "210";
    private String productId = "8rclN5cs11";
    private String userId = "433659";
    private String userAccessKey = "O1M4hrICDu9sUe9xXdDN7LzkuBpvFvhWupAXC609Tg6DxBitL+O9rQMtQHGO6Mg3";

    // 网络请求地址
    private String queryUrl = "https://iot-api.heclouds.com/thingmodel/query-device-property?product_id=" + productId + "&device_name=" + deviceName;
    private String controlUrl = "https://iot-api.heclouds.com/thingmodel/set-device-property";

    private String token; // 认证Token
    private Handler handler = new Handler();
    private ScrollView scrollView;
    private LinearLayout contentLayout; // 用于动态展示所有属性的布局

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 初始化UI组件
        scrollView = findViewById(R.id.scroll_view);
        contentLayout = findViewById(R.id.content_layout);

        // 生成Token
        try {
            token = generateToken();
        } catch (Exception e) {
            Log.e(TAG, "生成Token失败: " + e.getMessage());
            Toast.makeText(this, "认证失败", Toast.LENGTH_SHORT).show();
            return;
        }

        // 解决Android 9以上网络请求在主线程的问题
        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        // 启动定时刷新任务（每3秒刷新一次）
        startRefreshTask();
    }

    // 生成认证Token
    private String generateToken() throws UnsupportedEncodingException, NoSuchAlgorithmException, InvalidKeyException {
        String version = "2020-05-29";
        String resourceName = "userid/" + userId;
        String expirationTime = String.valueOf(System.currentTimeMillis() / 1000 + 3600); // 1小时有效期
        String signatureMethod = TokenUtil.SignatureMethod.SHA1.name().toLowerCase();
        return TokenUtil.assembleToken(version, resourceName, expirationTime, signatureMethod, userAccessKey);
    }

    // 启动定时刷新任务
    private void startRefreshTask() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // 子线程执行网络请求
                new Thread(() -> getOnenetData()).start();
                // 循环执行（3秒一次）
                handler.postDelayed(this, 3000);
            }
        }, 1000); // 延迟1秒后开始
    }

    // 获取OneNet平台数据
    private void getOnenetData() {
        HttpsURLConnection connection = null;
        StringBuilder response = null;
        try {
            URL url = new URL(queryUrl);
            connection = (HttpsURLConnection) url.openConnection();
            connection.setConnectTimeout(3000);
            connection.setReadTimeout(3000);
            connection.setRequestMethod("GET");
            connection.setRequestProperty("authorization", token);

            // 处理响应
            if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                InputStream is = connection.getInputStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                response = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) {
                    response.append(line);
                }
                br.close();
                is.close();

                // 解析并展示所有数据
                parseAndShowAllData(response.toString());
            } else {
                Log.e(TAG, "请求失败，响应码: " + connection.getResponseCode());
                runOnUiThread(() -> Toast.makeText(this, "数据获取失败", Toast.LENGTH_SHORT).show());
            }
        } catch (Exception e) {
            Log.e(TAG, "获取数据异常: " + e.getMessage());
            runOnUiThread(() -> Toast.makeText(this, "网络异常", Toast.LENGTH_SHORT).show());
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
        // 在getOnenetData()中添加日志
        Log.d(TAG, "请求URL: " + queryUrl);
        Log.d(TAG, "使用的Token: " + token);
// 打印服务器返回的完整响应
        Log.d(TAG, "服务器响应: " + response.toString());
    }

    // 解析JSON并展示所有属性
    private void parseAndShowAllData(String json) {
        JSONArray dataArray = null;
        try {
            JSONObject jsonObject = new JSONObject(json);
            dataArray = jsonObject.optJSONArray("data");
            if (dataArray == null || dataArray.length() == 0) {
                runOnUiThread(() -> showEmptyState());
                return;
            }

            // 在主线程更新UI
            JSONArray finalDataArray = dataArray;
            runOnUiThread(() -> {
                // 清空现有内容
                contentLayout.removeAllViews();

                // 遍历所有属性并添加到布局
                for (int i = 0; i < finalDataArray.length(); i++) {
                    try {
                        JSONObject item = finalDataArray.getJSONObject(i);
                        String identifier = item.optString("identifier"); // 属性标识
                        Object value = item.opt("value"); // 属性值（可能是字符串、数字、布尔等）

                        // 创建展示用的TextView
                        TextView textView = new TextView(this);
                        textView.setTextSize(16);
                        textView.setPadding(0, 12, 0, 12); // 上下内边距
                        textView.setTextColor(getResources().getColor(R.color.black));
                        // 格式：[标识]：[值]
                        textView.setText(String.format("[%s]：%s", identifier, value.toString()));

                        // 添加到布局
                        contentLayout.addView(textView);
                    } catch (JSONException e) {
                        Log.e(TAG, "解析单个属性失败: " + e.getMessage());
                    }
                }
            });
        } catch (JSONException e) {
            Log.e(TAG, "解析JSON失败: " + e.getMessage());
            runOnUiThread(() -> Toast.makeText(this, "数据解析失败", Toast.LENGTH_SHORT).show());
        }
        Log.d(TAG, "数据数组长度: " + dataArray.length());
        Log.d(TAG, "原始JSON数据: " + json);
    }

    // 当没有数据时显示
    private void showEmptyState() {
        contentLayout.removeAllViews();
        TextView emptyTv = new TextView(this);
        emptyTv.setTextSize(16);
        emptyTv.setTextColor(getResources().getColor(R.color.gray));
        emptyTv.setText("暂无设备数据");
        contentLayout.addView(emptyTv);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 停止刷新任务
        handler.removeCallbacksAndMessages(null);
    }
}
