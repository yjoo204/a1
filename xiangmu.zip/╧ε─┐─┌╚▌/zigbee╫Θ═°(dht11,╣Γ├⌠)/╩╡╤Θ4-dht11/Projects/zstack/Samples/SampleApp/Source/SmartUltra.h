#ifndef _SMARTULTRA_H__
#define _SMARTULTRA_H__
void SmartUltra_Init(uint8 taskID);
uint8 SmartUltra_GetVal(uint8 * buf,uint8 * buflen);
#endif