#ifndef __SMARTDHT11_H__
#define __SMARTDHT11_H__

void SmartDHT11_Init(uint8 TaskID);
uint8 SmartDHT11_GetVal(uint8 * buf,uint8 * buflen);
#endif