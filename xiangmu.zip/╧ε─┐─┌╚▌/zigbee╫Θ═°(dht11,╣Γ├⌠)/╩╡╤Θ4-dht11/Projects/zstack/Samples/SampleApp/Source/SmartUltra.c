/*
���������ģ��
*/
#include "osal.h"
#include "SmartUltra.h"
#include "OnBoard.h"
#include "stdio.h"
#include "SmartTimer.h"

#define SMART_ULTRA_TRIG_PIN              P1_4   //��������
#define SMART_ULTRA_ECHO_PIN              P0_0    //��������
#define SMART_ULTRA_BIT_SET               0x1
#define SMART_ULTRA_BIT_CLR               0x0

#define SMART_ULTRA_SEL                   P0SEL
#define SMART_ULTRA_DIR                   P0DIR
#define SMART_ULTRA_SET                   0x03
#define SMART_ULTRA_CLEAR                 (~0x03)



void SmartUltra_Init(uint8 taskID)
{
  (void)taskID;
 /* SMART_ULTRA_SEL &= SMART_ULTRA_CLEAR;
  SMART_ULTRA_DIR |= 0x01;                    //��������-���
  SMART_ULTRA_DIR &= ~0x02;                   //��������-����
  SMART_ULTRA_TRIG_PIN = SMART_ULTRA_BIT_CLR;*/
  P0SEL &= ~0x1;
  P0DIR &= ~0x1;
  P1SEL &= ~(0x1<<4);
  P1DIR |= 0x1<<4;
  SMART_ULTRA_TRIG_PIN = SMART_ULTRA_BIT_CLR;
}

uint8 SmartUltra_GetVal(uint8 * buf,uint8 * buflen)
{
  uint16 count;
  uint8 ret;
  uint16 Ultra_time;
  float  Distance;
  uint8 len;
  osal_memset(buf,0,*buflen);
  SMART_ULTRA_ECHO_PIN=SMART_ULTRA_BIT_CLR;
  SMART_ULTRA_TRIG_PIN = SMART_ULTRA_BIT_CLR;
  SMART_ULTRA_TRIG_PIN = SMART_ULTRA_BIT_SET;
  Delay_10us();
  Delay_10us();
  count = 0;
  SMART_ULTRA_TRIG_PIN = SMART_ULTRA_BIT_CLR;
  while(!SMART_ULTRA_ECHO_PIN)   //�ȴ����ظߵ�ƽ
  {
    Delay_us(1);
    if(++count >= 1000)         //��ʱ�˳�
    {
      break;
    }
  }
  len = sprintf((char*)buf,"a1:%d\r\n",count);
   HalUARTWrite(0,buf,len);
   osal_memset(buf,0,*buflen);
  count = 0;
  while(SMART_ULTRA_ECHO_PIN)   //30ms�ڳ����ߵ�ƽ��������෶Χ
  {
    Delay_us(1);
    count++;
    if(count >= 60000)
    {
       len = sprintf((char*)buf,"a2:%d\r\n",count);
   HalUARTWrite(0,buf,len);
   osal_memset(buf,0,*buflen);
      count = 0;
      break;
    }
  }
  len = sprintf((char*)buf,"a3:%d\r\n",count);
   HalUARTWrite(0,buf,len);
   osal_memset(buf,0,*buflen);
  if(count > 1 && count < 5000)
  {
    Ultra_time = count;                             //�ߵ�ƽʱ�䣬us
    Distance = (17000.0/1000000) * Ultra_time;           //��� ��λcm
    len = sprintf((char*)buf,"%1.1f\r\n",Distance);
    *buflen = len;
    HalUARTWrite(0,buf,len);
    ret = 1;
  }
  else
  {
    ret = 0;
  }
  return ret;
}