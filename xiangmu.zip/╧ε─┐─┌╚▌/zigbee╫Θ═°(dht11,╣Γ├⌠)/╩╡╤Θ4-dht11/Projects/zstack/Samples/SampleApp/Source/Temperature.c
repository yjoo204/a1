#include "hal_adc.h"
#include "Temperature.h"

void Temperature_Init(void)
{
    //APCFG |= 0x20;
    TR0 |= 0x01;
    ATEST &= 0xC0;
    ATEST |= 0x01;
    HalAdcInit ();
    HalAdcSetReference(HAL_ADC_REF_125V);
}

uint8 Temperature_GetVal(uint8 *buf)
{
    uint16 adcdata = HalAdcRead(HAL_ADC_CHANNEL_TEMP, HAL_ADC_RESOLUTION_12);
    uint16 temperature = (uint16)((adcdata - 1367.5) / 4.5);
    buf[0] = temperature / 10 + '0';
    buf[1] = temperature % 10 + '0';
    buf[2] = ' ';
    return TEMPERATURE_GET_OK;
}