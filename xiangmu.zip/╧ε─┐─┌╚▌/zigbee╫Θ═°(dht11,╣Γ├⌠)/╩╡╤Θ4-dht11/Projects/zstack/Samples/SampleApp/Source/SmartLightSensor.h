//����������.h
#ifndef __SMARTLIGHTSENSOR_H__
#define __SMARTLIGHTSENSOR_H__
#include "hal_types.h"

void SmartLightSensor_Init(uint8 TaskID);
uint8 SmartLightSensor_GetVal(uint8 *buf, uint8 *buflen);

#endif