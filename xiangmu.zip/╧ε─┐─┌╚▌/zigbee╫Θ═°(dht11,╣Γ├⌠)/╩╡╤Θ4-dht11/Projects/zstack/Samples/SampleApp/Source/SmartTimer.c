#include "osal.h"
#include "SmartTimer.h"
#include "OnBoard.h"

#define TIMER_INIT_NO       0x0
#define TIMER_INIT_OK       0x1
uint16   TimerCount  ;       //΢�����ֵ
uint16   SensorCount = 1 ;          //������ֵ
uint8    TimerInitFlag = TIMER_INIT_NO ;  //timer��ʼ����־
SmartTimerCB_t  SmartTimerCB = NULL;           //timer�ص�����



static void SmartTimer_Init(void)
{
  T3CTL = 0xEA;
  T3CCTL0 |= 0x1<<2;
  T3CC0 = 249;   //ÿ�����ж�һ��
  T3IE = 1;
  T3CTL |= 0x1<<4;
}

void SmartTimer_Start(uint16 TimerPeriosMs,SmartTimerCB_t TimerCB)
{
  SmartTimerCB = TimerCB;
  SensorCount = TimerPeriosMs;
  if(TimerInitFlag == TIMER_INIT_NO)
  {
    SmartTimer_Init();
    TimerInitFlag = TIMER_INIT_OK;
  }
}


HAL_ISR_FUNCTION( SetTimerIsr, T3_VECTOR )
{
  if(TimerCount == SensorCount)
  {
    if(SmartTimerCB)
    {
      SmartTimerCB();
    }
    TimerCount = 0;
  }
  TimerCount++;
}

void Delay_us(uint16 us) //1 us��ʱ
{
    MicroWait(us);   
}

void Delay_10us(void) //10 us��ʱ
{
  MicroWait(10);   
}

void Delay_ms(uint16 Time)//n ms��ʱ
{
  unsigned char i;
  while(Time--)
  {
    for(i=0;i<100;i++)
     Delay_10us();
  }
}

