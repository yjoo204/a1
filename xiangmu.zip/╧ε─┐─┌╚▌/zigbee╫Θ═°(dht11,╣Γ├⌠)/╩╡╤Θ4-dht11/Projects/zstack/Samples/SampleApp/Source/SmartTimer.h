#ifndef __SMARTTIMER_H__
#define __SMARTTIMER_H__




typedef void (*SmartTimerCB_t)(void);

void SmartTimer_Start(uint16 TimerPeriosMs,SmartTimerCB_t TimerCB);

void Delay_us(uint16 us);
void Delay_10us(void); //10 us��ʱ
void Delay_ms(uint16 Time);//n ms��ʱ

#endif