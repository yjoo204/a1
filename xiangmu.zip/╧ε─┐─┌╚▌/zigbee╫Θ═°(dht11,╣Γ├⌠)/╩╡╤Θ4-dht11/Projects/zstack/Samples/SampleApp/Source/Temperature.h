#ifndef __TEMPERATURE_H__
#define __TEMPERATURE_H__
#define TEMPERATURE_GET_OK 0x01

void Temperature_Init(void);
uint8 Temperature_GetVal(uint8 *buf);
#endif