#ifndef __DNUI_SAMPLEAPP_H__
#define __DNUI_SAMPLEAPP_H__

#define DNUI_SAMPLEAPP_ENDDEVICE_PERIODIC_MSG_EVT      0x1

#define DNUI_SAMPLEAPP_ENDPOINT                  30

#define DNUI_SAMPLEAPP_PROFILE_ID                0x0F09
#define DNUI_SAMPLEAPP_DEVICE_ID                 0x0
#define DNUI_SAMPLEAPP_DEVICE_VER                0x0

#define DNUI_SAMPLEAPP_CLUSTER_NUM                    1
#define DNUI_SAMPLEAPP_DATATEST_CLUSTER_ID           0x1



void DNUI_SampleApp_Init( uint8 task_id );
uint16 DNUI_SampleApp_ProcessEvent( uint8 task_id, uint16 events );

#endif